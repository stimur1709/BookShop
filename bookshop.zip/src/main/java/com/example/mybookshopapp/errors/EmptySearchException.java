package com.example.mybookshopapp.errors;

public class EmptySearchException extends Exception {
    public EmptySearchException(String message) {
        super(message);
    }
}
