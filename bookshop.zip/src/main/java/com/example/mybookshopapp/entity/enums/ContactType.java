package com.example.mybookshopapp.entity.enums;

public enum ContactType {
    PHONE,
    EMAIL;

    ContactType() {
    }
}
