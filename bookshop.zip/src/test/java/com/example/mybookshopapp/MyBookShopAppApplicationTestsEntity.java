package com.example.mybookshopapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBookShopAppApplicationTestsEntity {

    @Test
    void contextLoads() {
    }

}
